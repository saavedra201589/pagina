class EkommartTheme {

}

$(document).ready(function () {
    new EkommartTheme();
})
