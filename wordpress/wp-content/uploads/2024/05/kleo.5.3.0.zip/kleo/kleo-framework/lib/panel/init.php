<?php
define( 'SVQ_IMPORT_VERSION', '1.2' );
define( 'SVQ_IMPORT_FILE', __FILE__ );
define( 'SVQ_IMPORT_BASE_URL', get_template_directory_uri() . '/kleo-framework/lib/panel/' );
define( 'SVQ_IMPORT_BASE_PATH', get_template_directory() . '/kleo-framework/lib/panel/' );
define( 'SVQ_IMPORT_DEMO_URL', get_template_directory_uri() . '/lib/demo/' );
define( 'SVQ_IMPORT_DEMO_PATH', get_template_directory() . '/lib/demo/' );

require_once SVQ_IMPORT_BASE_PATH . 'inc/Plugin.php';
