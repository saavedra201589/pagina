		
<!-- SOCKET SECTION
================================================ -->

<div id="socket" class="socket-color">
    <div class="container">
        <div class="template-page tpl-no col-xs-12 col-sm-12">
            <div class="wrap-content">

                <div class="row">
                    <div class="col-sm-12">
                        <div class="gap-10"></div>
                    </div><!--end widget-->

                    <div class="col-sm-12">
                        <?php echo do_shortcode( sq_option( 'footer_text','' )); ?>
                    </div>

                    <div class="col-sm-12">
                        <div class="gap-10"></div>
                    </div><!--end widget-->
                </div><!--end row-->

            </div><!--end wrap-content-->
        </div><!--end template-page-->
    </div><!--end container-->
</div><!--end footer-->